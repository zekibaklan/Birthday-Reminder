//
//  OnboardingCollectionViewCell.swift
//  Projem
//
//  Created by Zeki Baklan on 7.04.2023.
//

import UIKit

class OnboardingCollectionViewCell: UICollectionViewCell {
    
    
    
    static let identifier = String(describing: OnboardingCollectionViewCell.self)
    
    @IBOutlet weak var slideImageView: UIImageView!
    
    @IBOutlet weak var slideTitleView: UILabel!
    @IBOutlet weak var slideDescriptionView: UILabel!
    
    
    
    func setup(_ slide: OnboardingSlide){
        slideImageView.image = slide.image
        slideTitleView.text = slide.title
        slideDescriptionView.text = slide.description
        
    }
}
