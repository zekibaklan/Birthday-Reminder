//
//  OnboardingViewController.swift
//  Projem
//
//  Created by Zeki Baklan on 7.04.2023.
//

import UIKit

class OnboardingViewController: UIViewController {
    var window: UIWindow?
    
    @IBOutlet weak var collecitonView: UICollectionView!
    
    @IBOutlet weak var nextBtn: UIButton!
    
    @IBOutlet weak var pageControl: UIPageControl!
    
    var slides: [OnboardingSlide] = []
    
    var currentPage = 0 {
        didSet{
            pageControl.currentPage = currentPage
            if currentPage == slides.count - 1 {
                
                nextBtn.setTitle("Başlayın!", for: .normal)
                
            }
            else
            {
                nextBtn.setTitle("İleri", for: .normal)
            }
        }
    }
    
    override func viewDidLoad() {
       
     
        
        
        super.viewDidLoad()
        
       
        
      
        
       
        
        
        
        slides = [
                    OnboardingSlide(title: "Hatırlamak Önemlidir", description: "Doğum günleri, sevdiklerimize olan sevgimizi ve bağlılığımızı göstermenin en iyi yollarından biridir.", image: #imageLiteral(resourceName: "image_2")),
                    OnboardingSlide(title: "Güzel Anılar Yaratın", description: "Sevdiklerimizin doğum günlerini hatırlamak sadece onlara ne kadar değer verdiğimizi göstermenin ve onları mutlu etmenin de bir yoludur.", image: #imageLiteral(resourceName: "image_6")),
                    OnboardingSlide(title: "Sevginizi Gösterin", description: "Uygulama, doğru zamanda hatırlatmalar alarak sevdiklerinizin özel günlerini kutlamanıza yardımcı olur.", image: #imageLiteral(resourceName: "image_5"))
                ]

       
    }
    

    @IBAction func nextBtnClicked(_ sender: UIButton) {
        if currentPage == slides.count - 1
        {
          
            performSegue(withIdentifier: "IkinciGecis", sender: self)
        }
        else
        {
            currentPage += 1
            let indexPath = IndexPath(item: currentPage, section: 0)
            collecitonView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
        }
      
        
    }
    

}
extension OnboardingViewController: UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return slides.count
         
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collecitonView.dequeueReusableCell(withReuseIdentifier: OnboardingCollectionViewCell.identifier, for: indexPath) as! OnboardingCollectionViewCell
        cell.setup(slides[indexPath.row] )
        return cell
        
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: collectionView.frame.height)
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        
        let width  = scrollView.frame.width
         currentPage = Int(scrollView.contentOffset.x / width)
       
    }
    
}
