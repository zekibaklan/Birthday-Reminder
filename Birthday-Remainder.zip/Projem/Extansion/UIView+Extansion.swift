//
//  UIView+Extansion.swift
//  Projem
//
//  Created by Zeki Baklan on 7.04.2023.
//

import UIKit



extension UIView
{
    @IBInspectable var cornerRadius : CGFloat{
        get {return self.cornerRadius}
        
        set{
            self.layer.cornerRadius = newValue
        }
        
    }
}
