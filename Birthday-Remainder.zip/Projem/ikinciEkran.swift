//
//  ikinciEkran.swift
//  Projem
//
//  Created by Zeki Baklan on 7.03.2023.
//

import UIKit
import CoreData
import Foundation
class ikinciEkran: UIViewController,UITextFieldDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    var datePicker = UIDatePicker()
  
   
    var selectedDate: Date?
   

    
    override func viewWillAppear(_ animated: Bool) {


        
        
    }
    
    
    
    var kisi : Kisi?
    
    override func viewDidLoad() {
       
       
        isimTF.placeholder = "İsim"
        soyisimTF.placeholder = "Soyisim"
        dogumGunuTF.placeholder = "Doğum Günü"
        kaydetBtn.setTitle("Kaydet", for: .normal)

        
        if kisi != nil {
            
            isimTF.text = kisi!.isim
            soyisimTF.text = kisi!.soyisim
            dogumGunuTF.text = kisi!.dogumgunu
            let gorseldata = kisi!.gorsel
            let image = UIImage(data: gorseldata!)
            imageView.image = image
         
            imageView.layer.cornerRadius = imageView.frame.size.width / 2.0
            imageView.clipsToBounds = true
            
        
            
        }
        
        
        super.viewDidLoad()
       
        createDatePicker()
        let gestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(klavyeyikapat))// Herhangi bir yere basıldığında Klavye Kapatma
        view.addGestureRecognizer(gestureRecognizer)
        
        
        imageView.isUserInteractionEnabled = true
        let imageGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(gorselSec))
        imageView.addGestureRecognizer(imageGestureRecognizer)
    }
    

    

    
    @objc public func kalangun()
    {
      
 
        let selectedDate = datePicker.date
        let Today = Date()
        
       
        let calendar = Calendar.current
       
     
        let dateComponents = calendar.dateComponents([.day], from:selectedDate, to: Today)
        

        if var days = dateComponents.day {
            
            days = days + 365   // yıl senkronizasyonu
            
            var i = 0     // 365 gün 6 saat farkı hesaplar
            if days >= 365        // Kalan gün 365ten büyükse ( yılı dahil ettiği için)
            {
                while days > 365 {
                    days -= 365       // 365ten küçük olana kadar çıkar
                    i = i + 1         // Artık saati hesaplamak için i değişkeni
                    if i == 4         // Her çıkarma 1 yılı temsil eder bu yüzden 4 yılda(6sa.4gün = 24sa) 1 gün        fazlalık çıkıyor.
                    {
                        days = days - 1     // Çıkan fazlalığı kalan günden çıkar
                        i = 0
                    }
                }
                          // Kalan gün
            }
           
           days = 365 - days  //  Negatif günleri hesapladığı için çıkarıyoruz
            
        
             // let daysString = String(days)
            
          
            
            if let kisi = kisi {
                kisi.setValue(days, forKey: "kalan")
            }
            
          
            
            
    
    }
    
    }
   
    
    @objc func gorselSec()
    {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        picker.allowsEditing = true
        present(picker, animated: true, completion: nil)
        
        imageView.layer.cornerRadius = imageView.frame.size.width / 2.0
        imageView.clipsToBounds = true
        
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        imageView.image = info[.editedImage] as? UIImage
        self.dismiss(animated: true)
        
    }
    
    
    
    
    
    @objc func klavyeyikapat()
    {
        
        view.endEditing(true) // Klavye kapatma fonksiyonu
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true) // Klavyede sağ alt köşede geç butonu

        return false
        
    }
    
    
    
    
    
    
    
    
    
    func createToolbar() -> UIToolbar{
        let toolbar = UIToolbar(frame: CGRect(origin: .zero, size: CGSize(width: 100, height: 44.0)))
     
        toolbar.sizeToFit()
        let doneBtn = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressed))
        toolbar.setItems([doneBtn], animated: true)
        
        return toolbar
       
    }
   
    func createDatePicker(){
        datePicker.preferredDatePickerStyle = .wheels
        datePicker.datePickerMode = .date
        datePicker.locale = Locale(identifier: "tr_TR")
        dogumGunuTF.inputView = datePicker
        dogumGunuTF.inputAccessoryView = createToolbar()
      
            
       
        
        
        let minDateString = "29-10-1923"     // Tarih Sınırlama
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        let minDate = dateFormatter.date(from: minDateString)
        
        datePicker.minimumDate = minDate
        datePicker.maximumDate = Date()
        datePicker.translatesAutoresizingMaskIntoConstraints = false
        
        
        UserDefaults.standard.set(dogumGunuTF.text, forKey: "lastSelectedBirthday")
        
        
        if let lastSelectedBirthdayString = UserDefaults.standard.string(forKey: "lastSelectedBirthday") {
            if let lastSelectedBirthday = dateFormatter.date(from: lastSelectedBirthdayString) {
                datePicker.date = lastSelectedBirthday
            }
        }
        
  
    }

    
  
    @objc func donePressed()  {
      
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .none
        
        
        self.dogumGunuTF.text = dateFormatter.string(from: datePicker.date)
        
        
       kalangun()
        
       
 
        
        
        
        
        
        
        
   
      
       
        self.view.endEditing(true)
        

   }

   
   
    

    

    
    
    
    
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var isimTF: UITextField!
    @IBOutlet weak var soyisimTF: UITextField!
    @IBOutlet weak var dogumGunuTF: UITextField!
    
    @IBOutlet weak var kaydetBtn: UIButton!
    
    @IBAction func kaydetButton(_ sender: UIButton) {
        
        
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
       
        if kisi == nil
        {
            if isimTF.text?.isEmpty ?? true || soyisimTF.text?.isEmpty ?? true || dogumGunuTF.text?.isEmpty ?? true{
                
                let alert = UIAlertController(title: "Uyarı", message: "Please enter the requested information.", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                alert.addAction(okAction)
                present(alert, animated: true, completion: nil)
                
                
            }
            else
            {
                
                let entity = NSEntityDescription.entity(forEntityName: "Kisi", in: context)
                let kisi =  NSManagedObject(entity: entity!, insertInto: context)
                kisi.setValue(isimTF.text!, forKey: "isim")
                kisi.setValue(soyisimTF.text!, forKey: "soyisim")
                kisi.setValue(dogumGunuTF.text!, forKey: "dogumgunu")
                kisi.setValue(UUID(), forKey: "id")
                let data = imageView.image?.jpegData(compressionQuality: 1)
                kisi.setValue(data, forKey: "gorsel")
                
                let selectedDate = datePicker.date
                
                let Today = Date()
               
                let calendar = Calendar.current
               
             
                let dateComponents = calendar.dateComponents([.day], from:selectedDate, to: Today)
                

                if var days = dateComponents.day {
                    
                    days = days + 365   // yıl senkronizasyonu
                    
                    var i = 0     // 365 gün 6 saat farkı hesaplar
                    if days >= 365        // Kalan gün 365ten büyükse ( yılı dahil ettiği için)
                    {
                        while days > 365 {
                            days -= 365       // 365ten küçük olana kadar çıkar
                            i = i + 1         // Artık saati hesaplamak için i değişkeni
                            if i == 4         // Her çıkarma 1 yılı temsil eder bu yüzden 4 yılda(6sa.4gün = 24sa) 1 gün        fazlalık çıkıyor.
                            {
                                days = days - 1     // Çıkan fazlalığı kalan günden çıkar
                                i = 0
                            }
                        }
                        // Kalan gün
                    }
                    
                    days = 365 - days  //  Negatif günleri hesapladığı için çıkarıyoruz
                    
                    kisi.setValue(days, forKey: "kalan")
                    
                }
                
            }
       
        }
        else if isimTF.text?.isEmpty ?? true || soyisimTF.text?.isEmpty ?? true || dogumGunuTF.text?.isEmpty ?? true{
            
            let alert = UIAlertController(title: "Uyarı", message: "Lütfen istenilen bilgileri giriniz.", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Tamam", style: .default, handler: nil)
            alert.addAction(okAction)
            present(alert, animated: true, completion: nil)
         
        }
    else
            {
                kisi?.isim = isimTF.text
                kisi?.soyisim = soyisimTF.text
                kisi?.dogumgunu = dogumGunuTF.text
                kisi?.gorsel = imageView.image?.jpegData(compressionQuality: 1)

            
        
               
             }
        (UIApplication.shared.delegate as! AppDelegate).saveContext()
    }
    
}
