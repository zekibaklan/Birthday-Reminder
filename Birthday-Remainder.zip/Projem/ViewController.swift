//
//  ViewController.swift
//  Projem
//
//  Created by Zeki Baklan on 6.03.2023.
//

import UIKit
import CoreData

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate
{
    
   
   

    
    

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return KisiListesi!.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let hucre =  countryTableView.dequeueReusableCell(withIdentifier: "countryCell", for: indexPath) as! CountryTVC
        
        let select = KisiListesi![indexPath.row]
       
        
        
        hucre.Lblisim.text = select.isim
        hucre.LblTarih.text = select.dogumgunu
        if let imageData = select.gorsel, let image = UIImage(data: imageData) {
            hucre.lblResim_.image = image
        }

        
        
        if select.kalan == 0
        {    
            hucre.LblKalanGun.text = "🎂"

        }
        else
        {
            hucre.LblKalanGun.text = String(select.kalan)
            
        }
        
        hucre.layer.cornerRadius = hucre.frame.height / 8
        hucre.countryView.layer.cornerRadius = hucre.countryView.frame.height / 2
        
    
        hucre.lblResim_.layer.cornerRadius = hucre.lblResim_.frame.width / 2
        hucre.lblResim_.clipsToBounds = true
        
        
        return hucre
    }
    
    
    @IBOutlet weak var countryTableView: UITableView!
    
    
    
    var isimDizisi = [String]()
    var idDizisi = [UUID]()
    
    var KisiListesi : [Kisi]?
    
    
    
    override func viewDidLoad() {
        
       let ikinciEkran = ikinciEkran()
        ikinciEkran.kalangun()
      
       
        super.viewDidLoad()
     
       
        countryTableView.delegate = self
        countryTableView.dataSource = self
        countryTableView.separatorStyle = .none
        countryTableView.showsVerticalScrollIndicator = false
     
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        
    }
   
    
    override func viewWillAppear(_ animated: Bool) {
       
        KisilerGetir()
    }
    
    
    
    
    
    func KisilerGetir()
    {
        let fr : NSFetchRequest<Kisi> =  Kisi.fetchRequest()
        fr.sortDescriptors =  [NSSortDescriptor(key: "kalan", ascending: true)]
        
        isimDizisi.removeAll(keepingCapacity: false)
        idDizisi.removeAll(keepingCapacity: false)
        
        do{
            KisiListesi = try (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext.fetch(fr)
            
            countryTableView.reloadData()
            for sonuc in KisiListesi!
            {
                if let isim = sonuc.value(forKey: "isim") as? String
                {
                    isimDizisi.append(isim)
                    
                }
                if let id = sonuc.value(forKey: "id") as? UUID
                {
                    idDizisi.append(id)
                   
                    
                }
                
                
            }
            
        }catch
        {
            print("hata")
        }
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toDetailsVC"
        {
            let hedefVc = segue.destination as! ikinciEkran
            hedefVc.kisi = KisiListesi![sender as! Int]
            
        }
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        performSegue(withIdentifier: "toDetailsVC", sender: indexPath.row)
    }
    
  
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete
        {
            let alert = UIAlertController(title: "Uyarı", message: "Kartı silmek istediğinize emin misiniz?", preferredStyle: .alert)
        
            alert.addAction(UIAlertAction(title: "Evet", style: .default, handler: { action in
                let appDelegate = UIApplication.shared.delegate as! AppDelegate
                let context = appDelegate.persistentContainer.viewContext
                let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Kisi")
                do {
                    let sonuclar = try context.fetch(fetchRequest)
                    for sonuc in sonuclar as! [NSManagedObject]
                    {
                        if let id = sonuc.value(forKey: "id") as? UUID
                        {
                            
                            if id == self.idDizisi[indexPath.row]
                            {
                                
                                context.delete(sonuc)
                                self.isimDizisi.remove(at: indexPath.row)
                                self.idDizisi.remove(at: indexPath.row)
                                do{
                                    
                                    try context.save()
                                    
                                    self.KisilerGetir()
                                    
                                }
                                catch
                                {
                                    print("Kisi silinemedi: \(error)")
                                }
                                break
                            }
                        }
                    }
                    
                }catch
                {
                    print("Hata")
                }
                
            }))
            
            alert.addAction(UIAlertAction(title: "Hayır", style: .cancel, handler: nil))
            self.present(alert, animated: true)
            
        }
}
        }

        
           
                
 
