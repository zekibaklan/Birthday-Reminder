//
//  CountryTVC.swift
//  Projem
//
//  Created by Zeki Baklan on 2.04.2023.
//

import UIKit

class CountryTVC: UITableViewCell {

    @IBOutlet weak var countryView: UIView!
    
    
    @IBOutlet weak var lblResim_: UIImageView!
    
    
    
    @IBOutlet weak var Lblisim: UILabel!
    
    @IBOutlet weak var LblTarih: UILabel!
    
    @IBOutlet weak var LblKalanGun: UILabel!
    
    
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
