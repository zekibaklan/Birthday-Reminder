//
//  GecisViewController.swift
//  Projem
//
//  Created by Zeki Baklan on 6.04.2023.
//

import UIKit

class GecisViewController: UIViewController {
    
    override func viewDidLoad() {
      

        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1) {
            self.performSegue(withIdentifier: "Ilkgecis", sender: nil)
        }
    }
   
    
    
    @IBOutlet weak var myImage: UIImageView!
   
    
}

        
